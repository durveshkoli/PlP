package com.cg.helper;


import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PDFHelper {

	public static final String DEST = System.getProperty("user.dir") + "/src/";

	Document document;
	PdfPTable table;
	static int rowIndex = 0;

	public void createPdf(String filename) throws DocumentException, IOException {
		PdfWriter.getInstance(document, new FileOutputStream(DEST + filename));
		document.open();
		document.add(new Paragraph("**************************************************************************************************"));
		document.add(new Paragraph("***********************************TestNG Report!!************************************************"));
		document.add(new Paragraph("*************************************************************************************************\n"));
//		document.newPage();
	}

	public PDFHelper(Document document) {
		super();
		this.document = document;
	}

	public void createTable() {
		// TODO Auto-generated method stub
		table = new PdfPTable(new float[] {5, 10, 10, 5 });
		table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell("Steps");
		table.addCell("Expected");
		table.addCell("Actual");
		table.addCell("Status");
		table.setHeaderRows(1);

		PdfPCell[] cells = table.getRow(0).getCells();
		for (int j = 0; j < cells.length; j++) {
			cells[j].setBackgroundColor(BaseColor.LIGHT_GRAY);
		}

	}

	public void addRow(String step, String expected, String actual, int status)
			throws MalformedURLException, IOException, DocumentException {
		
		table.addCell(step);
		table.addCell(expected);
		table.addCell(actual);

		String Status = new String();

		switch (status) {
		case 1:
			Status = "PASSED";
			break;
		case 2:
			Status = "FAILED";
			break;
		case 3:
			Status = "SKIPED";
			break;
		}

		table.addCell(Status);

		++rowIndex;
		PdfPCell[] cells = table.getRow(table.getLastCompletedRowIndex()).getCells();

		switch (status) {
		case 1:
			cells[cells.length - 1].setBackgroundColor(BaseColor.GREEN);
			break;
		case 2:
			cells[cells.length - 1].setBackgroundColor(BaseColor.RED);
			break;
		case 3:
			cells[cells.length - 1].setBackgroundColor(BaseColor.YELLOW);
			break;
		}

	
	}
	
public void addImage() throws DocumentException, MalformedURLException, IOException {
		
		document.add(table);
		document.add(new Paragraph("Screenshots : \n"));
		 Image img1 = Image.getInstance("C://Vishnu//PLP//src//Testcase1.png");
		 img1.scaleAbsolute(300f, 150f);
	     document.add(img1);
	     Image img2 = Image.getInstance("C://Vishnu//PLP//src//Testcase2.png");
	     img2.scaleAbsolute(300f, 150f);
	     document.add(img2);
		 Image img3 = Image.getInstance("C://Vishnu//PLP//src//Testcase3.png");
		 img3.scaleAbsolute(300f, 150f);
	     document.add(img3);
	     Image img4 = Image.getInstance("C://Vishnu//PLP//src//Testcase4.png");
	     img4.scaleAbsolute(300f, 150f);
	     document.add(img4);
		 Image img5 = Image.getInstance("C://Vishnu//PLP//src//Testcase5.png");
		 img5.scaleAbsolute(300f, 150f);
	     document.add(img5);
//	
	}

	public void savePdf() throws DocumentException {

		document.close();
	}


}