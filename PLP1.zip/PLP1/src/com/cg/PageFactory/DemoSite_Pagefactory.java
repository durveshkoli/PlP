package com.cg.PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DemoSite_Pagefactory {
	WebDriver driver;

	@FindBy(xpath = "//*[@id=\"top-links\"]/ul/li[2]/a/span[1]")
	public WebElement MyAccount;

	@FindBy(xpath = "//*[@id=\"top-links\"]/ul/li[2]/ul/li[1]/a")
	public WebElement Register;

	@FindBy(id = "input-firstname")
	public WebElement firstname;

	@FindBy(id = "input-lastname")
	public WebElement lastname;

	@FindBy(id = "input-email")
	public WebElement email;

	@FindBy(id = "input-telephone")
	public WebElement telephone;

	@FindBy(id = "input-password")
	public WebElement password;

	@FindBy(id = "input-confirm")
	public WebElement confirm;

	@FindBy(xpath = "//*[@id=\"content\"]/form/fieldset[3]/div/div/label[1]/input")
	public WebElement radio;

	@FindBy(xpath = "//*[@id=\"content\"]/form/div/div/input[1]")
	public WebElement agree;

	@FindBy(xpath = "//*[@id=\"content\"]/form/div/div/input[2]")
	public WebElement Continue;
	
	@FindBy(xpath = "//*[@id=\"content\"]/div/div/a")
	public WebElement SecContinue;
	
	@FindBy(xpath = "//*[@id=\"top-links\"]/ul/li[2]/ul/li[2]/a")
	public WebElement Login;
	
	@FindBy(id = "input-password")
	public WebElement Lpassword;
	
	@FindBy(id = "input-email")
	public WebElement e_Mail;
	
	@FindBy(xpath = "//*[@id=\"content\"]/div/div[2]/div/form/input")
	public WebElement Loginbutton;
	
	@FindBy(xpath = "//*[@id=\"content\"]/ul[1]/li[1]/a")
	public WebElement Edit;
	
	@FindBy(id = "input-lastname")
	public WebElement LLastname;
	
	@FindBy(xpath = "//*[@id=\"input-telephone\"]")
	public WebElement Ltelephone;
	
	@FindBy(xpath = "//*[@id=\"content\"]/form/div/div[2]/input")
	public WebElement LContinue;
	
	@FindBy(linkText = "Change your password")
	public WebElement Mpassword;
	
	@FindBy(xpath = "//*[@id=\"input-password\"]")
	public WebElement MCpassword;
	
	@FindBy(xpath = "//*[@id=\"input-confirm\"]")
	public WebElement MConfirm;
	
	@FindBy(xpath = "//*[@id=\"content\"]/form/div/div[2]/input")
	public WebElement MpConfirm;
	
	@FindBy(xpath = "//*[@id=\"top-links\"]/ul/li[2]/ul/li[5]/a")
	public WebElement logout;
	
	@FindBy(xpath = "//*[@id=\"form-currency\"]/div/button/i")
	public WebElement currencydrpdwn;

	@FindBy(xpath = "//*[@id=\"account-login\"]/ul/li[3]/a")
	public WebElement verifylogin;
	
	@FindBy(xpath = "//*[@id=\"content\"]/h2[1]")
	public WebElement verifyloginpage;
	
	@FindBy(xpath = "//*[@id=\"logo\"]/h1/a")
	public WebElement verifyhomepage;
	
	@FindBy(xpath = "//*[@id=\"form-currency\"]/div/ul/li[2]/button")
	public WebElement verifycurrencydrop;
	
	@FindBy(xpath = "//*[@id=\"common-success\"]/ul/li[3]/a")
	public WebElement verifylogout;
	
	@FindBy(xpath = "//*[@id=\"top-links\"]/ul/li[2]/ul/li[5]/a")
	public WebElement verifylogoutdrpdown;
	
	@FindBy(xpath = "//*[@id=\"form-currency\"]/div/ul/li[1]/button")
	public WebElement eurocurrency;

	@FindBy(xpath = "//*[@id=\"form-currency\"]/div/ul/li[2]/button")
	public WebElement poundcurrency;

	@FindBy(css = "#form-currency > div > ul > li:nth-child(3) > button")
	public WebElement dollarcurrency;

	@FindBy(id = "cart-total")
	public WebElement carticon;

	@FindBy(xpath = "//*[@id=\"content\"]/div[2]/div[1]/div/div[2]/h4/a")
	public WebElement macbook;

	@FindBy(xpath = "//*[@id=\"content\"]/div[1]/div[2]/ul[2]/li[1]/h2")
	public WebElement macbookeuroprice;

	@FindBy(css = "#content > div > div.col-sm-4 > ul:nth-child(4) > li:nth-child(1) > h2")
	public WebElement macbookpoundprice;

	@FindBy(xpath = "//*[@id=\"content\"]/div/div[2]/ul[2]/li[1]/h2")
	public WebElement macbookdollarprice;
	
	@FindBy(xpath = "//*[@id=\"top-links\"]/ul/li[2]/a/span[2]")
	public WebElement myaccountdrpdwn;
	
	@FindBy(css = "#top-links > ul > li.dropdown.open > ul > li:nth-child(2) > a")
	public WebElement login;
	
	@FindBy(id = "input-email")
	public WebElement username;
	
	@FindBy(id = "input-password")
	public WebElement pppassword;
	
	@FindBy(xpath = "//*[@id=\"content\"]/div/div[2]/div/form/input")
	public WebElement loginbtn;
	
	@FindBy(xpath = "//*[@id=\"logo\"]/h1/a")
	public WebElement homelink;
	
	@FindBy(css = "#content > div.row > div:nth-child(1) > div > div.caption > p.price > span")
	public WebElement productprice;
	
	@FindBy(css = "#content > div.row > div:nth-child(1) > div > div.button-group > button:nth-child(1)")
	public WebElement addcart;
	
	@FindBy(linkText = "shopping cart")
	public WebElement gocart;
	
	@FindBy(xpath = "//*[@id=\"cart\"]/ul/li[2]/div/p/a[1]")
	public WebElement viewcart;
	
	@FindBy(css = "#content > form > div > table > tbody > tr > td:nth-child(5)")
	public WebElement cartprice;
	
	@FindBy(xpath = "//*[@id=\"top-links\"]/ul/li[2]/a/span[2]")
	public WebElement myaccountdrpforlogout;
	
	@FindBy(css = "#top-links > ul > li.dropdown.open > ul > li:nth-child(5) > a")
	public WebElement pplogout;
	

	public DemoSite_Pagefactory(WebDriver driver1) {

		this.driver = driver1;
		PageFactory.initElements(driver1, this);
	}
}
