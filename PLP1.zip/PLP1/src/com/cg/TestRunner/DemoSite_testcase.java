package com.cg.TestRunner;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Hashtable;

import org.apache.commons.io.FileUtils;
import org.apache.poi.util.DocumentFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cg.ExcelReader.ReaderFromExcel;
import com.cg.PageFactory.DemoSite_Pagefactory;
import com.cg.helper.PDFHelper;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;


public class DemoSite_testcase {
	PDFHelper pdfHelper;
	DemoSite_Pagefactory Site;
	WebDriver driver;
	
	@BeforeClass
	public void beforeClass() throws DocumentException, IOException {
		Document document = new Document();
		pdfHelper = new PDFHelper(document);
		pdfHelper.createPdf("testReport.pdf");
		pdfHelper.createTable();
		
	}

	@BeforeMethod
	public void DemoSite() throws DocumentFormatException, IOException, DocumentException {
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.opencart.com");
		Site = new DemoSite_Pagefactory(driver);
		
	}

	@Test(priority = 0, dataProvider = "InValidLogin")
	public void InValidLogin(Hashtable<String, String> Str) throws Exception {

		Site.MyAccount.click();
		String expected = Site.login.getText();
		String Actual = "Login";
		
		System.out.println("The Title is : " + expected);
		
		if (expected.equals(Actual)) {
			//this.takeSnapShot(driver, "C://ARAVIND//EC WORK//PLP_Project//src//Testcase2.png");
			pdfHelper.addRow("step 2", "Dropdown should list with :" + expected, "Dropdown is listed with:" + Actual,
					1);
			// System.out.println("PASSED: Step 1: The Expected Title is " + expected + "
			// The Actual Title is " + Actual);
		} else {
			//this.takeSnapShot(driver, "C://ARAVIND//EC WORK//PLP_Project//src//Testcase2.png");
			pdfHelper.addRow("step 2", "Dropdown should list with :" + expected, "Dropdown is listed with:" + Actual,
					2);
			// System.out.println("FAILED: Step 1: The Expected Title is " + expected + "
			// The Actual Title is " + Actual);
		}
		Thread.sleep(1000);
		Site.Login.click();
		String expected1 = Site.verifylogin.getText();
		String Actual1 = "Login";
		
		System.out.println("The Title is : " + expected1);
		
		if (expected1.equals(Actual1)) {
			//this.takeSnapShot(driver, "C://ARAVIND//EC WORK//PLP_Project//src//Testcase3.png");
			pdfHelper.addRow("step 3", "The page should navigate to:" + expected1,
					"The page is navigated to:" + Actual1, 1);
			// System.out.println("PASSED: Step 1: The Expected Title is " + expected + "
			// The Actual Title is " + Actual);
		} else {
			//this.takeSnapShot(driver, "C://ARAVIND//EC WORK//PLP_Project//src//Testcase3.png");
			pdfHelper.addRow("step 3", "The page should navigate to:" + expected1,
					"The page is navigated to:" + Actual1, 2);
			// System.out.println("FAILED: Step 1: The Expected Title is " + expected + "
			// The Actual Title is " + Actual);
		}

		Thread.sleep(1000);
		Site.e_Mail.sendKeys(Str.get("E-Mail"));
		Thread.sleep(1000);
		Site.Lpassword.sendKeys(Str.get("Password"));
		Thread.sleep(1000);
		Site.Loginbutton.click();
		Thread.sleep(1000);
		Site.loginbtn.click();
//		String expected2 = Site.verifyloginpage.getText();
//		String Actual2 = "My Account";
//		System.out.println("The Title is : " + expected2);
		String sc = driver.findElement(By.xpath("//*[@id=\"account-login\"]/div[1]")).getText();
		String expected99 = "Warning: No match for E-Mail Address and/or Password.";
		System.out.println("" + expected99);
		if (sc.equals(expected99)) {
			pdfHelper.addRow("step 1",expected99, sc, 1);
			this.takeSnapShot(driver, "C://Vishnu//PLP//src//Testcase1.png");
			System.out.println("Passed");
		} else {
			pdfHelper.addRow("step 1",expected99, sc, 2);
			this.takeSnapShot(driver, "C://Vishnu//PLP//src//Testcase1.png");
			System.out.println("Failed");
		}
	}

/*	 //Account Registration for mandatory fields
	@Test(priority = 2, dataProvider = "UserRegisterDetails")
	public void UserRegisterDetails(Hashtable<String, String> Str) throws InterruptedException, NoSuchElementException {

		Site.MyAccount.click();
		Thread.sleep(1000);
		Site.Register.click();
		Thread.sleep(1000);
		Site.firstname.sendKeys(Str.get("First Name"));
		Site.lastname.sendKeys(Str.get("Last Name"));
		Site.email.sendKeys(Str.get("E-Mail"));
		Site.telephone.sendKeys(Str.get("Telephone"));
		Site.password.sendKeys(Str.get("Password"));
		Site.confirm.sendKeys(Str.get("Password Confirm"));
		Site.agree.click();
		Thread.sleep(1000);
		Site.Continue.click();
		Thread.sleep(1000);
		Site.SecContinue.click();
		Thread.sleep(1000);
		

	}
	Account Registration for Non-mandatory fields*/
	@Test(priority = 1, dataProvider = "RegisterNon")
	public void Register_Title(Hashtable<String, String> Str) throws Exception {

		Site.MyAccount.click();
		Thread.sleep(1000);
		String expected = Site.login.getText();
		String Actual = "Login";
		
		System.out.println("The Title is : " + expected);
		
		if (expected.equals(Actual)) {
			//this.takeSnapShot(driver, "C://ARAVIND//EC WORK//PLP_Project//src//Testcase2.png");
			pdfHelper.addRow("step 2", "Dropdown should list with :" + expected, "Dropdown is listed with:" + Actual,
					1);
			// System.out.println("PASSED: Step 1: The Expected Title is " + expected + "
			// The Actual Title is " + Actual);
		} else {
			//this.takeSnapShot(driver, "C://ARAVIND//EC WORK//PLP_Project//src//Testcase2.png");
			pdfHelper.addRow("step 2", "Dropdown should list with :" + expected, "Dropdown is listed with:" + Actual,
					2);
			// System.out.println("FAILED: Step 1: The Expected Title is " + expected + "
			// The Actual Title is " + Actual);
		}
		Site.Register.click();
		Thread.sleep(1000);
		Site.agree.click();
		Thread.sleep(1000);
		Site.Continue.click();
		Thread.sleep(1000);
		String sc = driver.findElement(By.cssSelector("#content > p")).getText();
		String expected2 = "If you already have an account with us, please login at the login page.";
		System.out.println("verify " + expected2);
		pdfHelper.addRow("step 2",expected2, sc, 1);
		if (sc.equals(expected2)) {
			
			this.takeSnapShot(driver, "C://Vishnu//PLP//src//Testcase2.png");
			System.out.println("Passed");
		} else {
			pdfHelper.addRow("step 2",expected2, sc, 2);
			//this.takeSnapShot(driver, "C://Vishnu//PLP//src//Testcase2.png");
			//System.out.println("Failed");
		}
		Site.firstname.sendKeys(Str.get("First Name"));
		Site.lastname.sendKeys(Str.get("Last Name"));
		Site.email.sendKeys(Str.get("E-Mail"));
		Site.telephone.sendKeys(Str.get("Telephone"));
		Site.password.sendKeys(Str.get("Password"));
		Site.confirm.sendKeys(Str.get("Password Confirm"));
		Site.radio.click();
		Thread.sleep(1000);
		Site.Continue.click();
		Thread.sleep(1000);
		Site.SecContinue.click();
		Thread.sleep(1000);
		String actual = driver.getTitle();
		String expected1 = "My Account";
		if (actual.equals(expected1)) {
			pdfHelper.addRow("step 3",expected1, actual, 1);
			this.takeSnapShot(driver, "C://Vishnu//PLP//src//Testcase3.png");
			System.out.println("Passed");
		} else {
			pdfHelper.addRow("step 3",expected1, actual, 2);
			this.takeSnapShot(driver, "C://Vishnu//PLP//src//Testcase3.png");
			System.out.println("Failed");
		}

		System.out.println("The title is : " + actual);
		System.out.println(
				" Step1 : " + " The title of the page should be :" + expected1 + " The title of the page is:" + actual);

	}

	@Test(priority = 3, dataProvider = "Modify")
	public void ModifyDetails(Hashtable<String, String> Str) throws Exception {

		Site.MyAccount.click();
		Thread.sleep(1000);
		String expected = Site.login.getText();
		String Actual = "Login";
		
		System.out.println("The Title is : " + expected);
		
		if (expected.equals(Actual)) {
			//this.takeSnapShot(driver, "C://ARAVIND//EC WORK//PLP_Project//src//Testcase2.png");
			pdfHelper.addRow("step 2", "Dropdown should list with :" + expected, "Dropdown is listed with:" + Actual,
					1);
			// System.out.println("PASSED: Step 1: The Expected Title is " + expected + "
			// The Actual Title is " + Actual);
		} else {
			//this.takeSnapShot(driver, "C://ARAVIND//EC WORK//PLP_Project//src//Testcase2.png");
			pdfHelper.addRow("step 2", "Dropdown should list with :" + expected, "Dropdown is listed with:" + Actual,
					2);
			// System.out.println("FAILED: Step 1: The Expected Title is " + expected + "
			// The Actual Title is " + Actual);
		}
		Site.Login.click();
		Thread.sleep(1000);
		Site.e_Mail.clear();
		Site.e_Mail.sendKeys(Str.get("E-Mail"));
		Site.Lpassword.clear();
		Site.Lpassword.sendKeys(Str.get("Password_login"));
		Site.Loginbutton.click();
		Site.Edit.click();
		Site.LLastname.clear();
		Site.LLastname.sendKeys(Str.get("Last Name"));
		Site.Ltelephone.clear();
		Site.Ltelephone.sendKeys(Str.get("Telephone"));
		Site.LContinue.click();
		Thread.sleep(1000);
		String sc = driver.findElement(By.cssSelector(".alert")).getText();
		String expected2 = "Success: Your account has been successfully updated.";
		System.out.println("verify " + expected2);
		if (sc.equals(expected2)) {
			pdfHelper.addRow("step 4",expected2, sc, 1);
			this.takeSnapShot(driver, "C://Vishnu//PLP//src//Testcase4.png");
			System.out.println("Passed");
		} else {
			pdfHelper.addRow("step 4",expected2, sc, 2);
			this.takeSnapShot(driver, "C://Vishnu//PLP//src//Testcase4.png");
			System.out.println("Failed");
		}
		Site.Mpassword.click();
		Thread.sleep(1000);
		Site.MCpassword.clear();
		Site.MCpassword.sendKeys(Str.get("Password"));
		Site.MConfirm.clear();
		Site.MConfirm.sendKeys(Str.get("Password Confirm"));
		Site.MpConfirm.click();
		Thread.sleep(1000);
		String src = driver.findElement(By.cssSelector(".alert")).getText();
		String expected1 = "Success: Your password has been successfully updated.";
		System.out.println("verify " + expected1);
		if (src.equals(expected1)) {
			pdfHelper.addRow("step 5",expected1, src, 1);
			this.takeSnapShot(driver, "C://Vishnu//PLP//src//Testcase5.png");
			System.out.println("Passed");
		} else {
			pdfHelper.addRow("step 5",expected1, src, 2);
			this.takeSnapShot(driver, "C://Vishnu//PLP//src//Testcase5.png");
			System.out.println("Failed");
		}
		Site.MyAccount.click();
		Thread.sleep(1000);
		Site.logout.click();
		Thread.sleep(1000);

	}
	

	
	
	@AfterClass
	public void Close() throws DocumentException, MalformedURLException, IOException {
	
		//driver.quit();
		pdfHelper.addImage();
		pdfHelper.savePdf();
	}
	public static String capture(WebDriver driver) throws IOException {

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File("src/../ErrImages/" + System.currentTimeMillis() + ".png");
		String errflpath = Dest.getAbsolutePath();
		FileUtils.copyFile(scrFile, Dest);
		return errflpath;
	}

	public static void takeSnapShot(WebDriver webdriver, String fileWithPath) throws Exception {

		// Convert web driver object to TakeScreenshot
		TakesScreenshot scrShot = ((TakesScreenshot) webdriver);
		// Call getScreenshotAs method to create image file
		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
		// Move image file to new destination
		File DestFile = new File(fileWithPath);
		// Copy file at destination
		FileUtils.copyFile(SrcFile, DestFile);

}
	
	
	@DataProvider
	public Object[][] UserRegisterDetails() throws IOException {

		String filename = "RegisterDetails.xlsx";
		String filepath = "C:\\Vishnu\\PLP1\\src\\com\\cg\\Testdata";
		String sheetname = "Sheet1";
		return ReaderFromExcel.ReadExcelData(filepath, filename, sheetname);
	}
	
	@DataProvider
	public Object[][] RegisterNon() throws IOException {

		String filename = "RegisterDetails.xlsx";
		String filepath = "C:\\Vishnu\\PLP1\\src\\com\\cg\\Testdata";
		String sheetname = "Sheet2";
		return ReaderFromExcel.ReadExcelData(filepath, filename, sheetname);
	}

	@DataProvider
	public Object[][] Modify() throws IOException {

		String filename = "RegisterDetails.xlsx";
		String filepath = "C:\\Vishnu\\PLP1\\src\\com\\cg\\Testdata";
		String sheetname = "Sheet3";
		return ReaderFromExcel.ReadExcelData(filepath, filename, sheetname);
	}

	@DataProvider
	public Object[][] InValidLogin() throws IOException {

		String filename = "RegisterDetails.xlsx";
		String filepath = "C:\\Vishnu\\PLP1\\src\\com\\cg\\Testdata";
		String sheetname = "Sheet4";
		return ReaderFromExcel.ReadExcelData(filepath, filename, sheetname);
	}

}
